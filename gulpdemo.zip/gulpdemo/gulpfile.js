var gulp = require('gulp');
var concat = require('gulp-concat');
var sass = require('gulp-sass');
var cssminify = require('gulp-clean-css');
var uglify = require('gulp-uglify');
var browsersync = require('browser-sync').create();


gulp.task('default',['sass','js','html','watch'],function() {
    console.log("** Build Complete ***");
});

gulp.task('html',function() {
    return gulp.src('./src/**/*.html')
        .pipe(gulp.dest('dist'))
        .pipe(browsersync.reload({
            stream: true
        }))
});

gulp.task('sass',function() {
    return gulp.src('./src/scss/**/*.scss')
            .pipe(sass())
            .pipe(concat('styles.css'))
            .pipe(cssminify())
            .pipe(gulp.dest('dist/css'))
            .pipe(browsersync.reload({
                stream: true
            }))
});

gulp.task('js',function() {
    return gulp.src('./src/scripts/**/*.js')
            .pipe(concat('main.js'))
            .pipe(uglify())
            .pipe(gulp.dest('dist/scripts'))
            .pipe(browsersync.reload({
                stream: true
            }))
});

gulp.task('browsersync',function() {
    browsersync.init({
        server: {
            baseDir: 'dist'
        }
    })
});

gulp.task('watch',['browsersync','sass','js'],function() {
    gulp.watch('./src/scss/**/*.scss',['sass']);
    gulp.watch('./src/scripts/**/*.js',['js']);
    gulp.watch('./src/**/*.html',['html']);
});



