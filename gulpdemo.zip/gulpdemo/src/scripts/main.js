function Test() {
    console.log("This is a test");
}

function Add(a, b) {
    return a + b;
}

function Mult(a,b) {
    return a* b;
}