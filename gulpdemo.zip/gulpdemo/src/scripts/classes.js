function Customer(id, name) {
    this.ID = id;
    this.Name = name;

    this.getDetails = function() {
        return this.ID + " " + this.Name;
    }

    this.getID = function() {
        return this.ID;
    }

    this.getName = function() {
        return this.Name;
    }
}